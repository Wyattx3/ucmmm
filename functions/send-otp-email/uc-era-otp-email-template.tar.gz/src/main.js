import { Client, Databases, ID } from 'node-appwrite';

export default async ({ req, res, log, error }) => {
  try {
    log('🚀 Send OTP Email function triggered');
    
    // Debug: Log available req properties
    log('Available req properties:', Object.keys(req));
    log('req.variables:', req.variables);
    log('process.env keys:', Object.keys(process.env || {}));
    
    // Get environment variables with fallbacks
    const getEnvVar = (key, fallback) => {
      // Try multiple sources for environment variables
      return (req.variables && req.variables[key]) || 
             process.env[key] || 
             fallback;
    };
    
    const endpoint = getEnvVar('APPWRITE_FUNCTION_ENDPOINT', 'https://nyc.cloud.appwrite.io/v1');
    const projectId = getEnvVar('APPWRITE_FUNCTION_PROJECT_ID', '688813660017c877f06e');
    const apiKey = getEnvVar('APPWRITE_API_KEY', '');
    const resendApiKey = getEnvVar('RESEND_API_KEY', '');
    
    log('Using endpoint:', endpoint);
    log('Using project ID:', projectId);
    log('API key present:', !!apiKey);
    log('Resend API key present:', !!resendApiKey);

    // Initialize Appwrite client
    const client = new Client()
      .setEndpoint(endpoint)
      .setProject(projectId);
      
    // Only set API key if available  
    if (apiKey) {
      client.setKey(apiKey);
    }

    const databases = new Databases(client);

    // Parse request body
    log('Request body:', req.body);
    log('Request bodyJson:', req.bodyJson);
    log('Request bodyText:', req.bodyText);
    
    // Try different sources for request data
    let requestData;
    try {
      if (req.bodyJson) {
        requestData = req.bodyJson;
      } else if (req.body) {
        requestData = JSON.parse(req.body);
      } else if (req.bodyText) {
        requestData = JSON.parse(req.bodyText);
      } else {
        requestData = JSON.parse(req.payload || '{}');
      }
    } catch (parseError) {
      error('Failed to parse request data:', parseError.message);
      requestData = {};
    }
    
    log('Parsed request data:', requestData);
    const { userId, email, userName, otpCode } = requestData;

    if (!email || !otpCode) {
      error('Missing required fields: email or otpCode');
      return res.json({
        success: false,
        error: 'Missing required fields: email or otpCode'
      }, 400);
    }

    log(`📧 Sending OTP to: ${email}`);

    // Check if RESEND_API_KEY is available
    if (!resendApiKey) {
      error('RESEND_API_KEY is not configured');
      return res.json({
        success: false,
        error: 'Email service is not properly configured'
      }, 500);
    }

    // Send email using Resend API
    const resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'UC ERA <noreply@unbreakablecube.com>',
        to: [email],
        subject: '🔐 UC ERA - Email Verification Code',
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>UC ERA - Email Verification</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&family=JetBrains+Mono:wght@400;700&display=swap');
              
              * { box-sizing: border-box; }
              
              .pixel-font {
                font-family: 'Press Start 2P', monospace;
                line-height: 1.6;
                text-rendering: optimizeLegibility;
              }
              
              .mono-font {
                font-family: 'JetBrains Mono', monospace;
                line-height: 1.5;
              }
              
              .pixel-block {
                background: 
                  repeating-linear-gradient(0deg, #2563eb 0px, #2563eb 4px, #1d4ed8 4px, #1d4ed8 8px),
                  repeating-linear-gradient(90deg, #2563eb 0px, #2563eb 4px, #1e40af 4px, #1e40af 8px);
                border: 3px solid #1e293b;
                box-shadow: 
                  inset 2px 2px 0 #60a5fa,
                  inset -2px -2px 0 #1e40af,
                  4px 4px 0 #334155;
                image-rendering: pixelated;
              }
              
              .glow {
                background: linear-gradient(135deg, #3b82f6, #1d4ed8, #1e40af);
                border: 3px solid #1e293b;
                box-shadow: 
                  0 0 20px rgba(59, 130, 246, 0.4),
                  inset 0 2px 4px rgba(255,255,255,0.2);
                animation: gentleGlow 3s ease-in-out infinite;
              }
              
              @keyframes gentleGlow {
                0%, 100% { 
                  box-shadow: 
                    0 0 20px rgba(59, 130, 246, 0.4),
                    inset 0 2px 4px rgba(255,255,255,0.2);
                }
                50% { 
                  box-shadow: 
                    0 0 30px rgba(59, 130, 246, 0.6),
                    inset 0 2px 4px rgba(255,255,255,0.3);
                }
              }
              
              .float {
                animation: floatUp 4s ease-in-out infinite;
              }
              
              @keyframes floatUp {
                0%, 100% { transform: translateY(0px); }
                50% { transform: translateY(-6px); }
              }
              
              .pixel-border {
                border: 4px solid #1e293b;
                border-image: 
                  repeating-linear-gradient(45deg, 
                    #1e293b 0px, #1e293b 8px, 
                    #475569 8px, #475569 16px
                  ) 4;
              }
            </style>
          </head>
          <body style="margin: 0; padding: 0; background: linear-gradient(180deg, #f1f5f9 0%, #e2e8f0 50%, #cbd5e1 100%); min-height: 100vh; font-family: system-ui, -apple-system, sans-serif;">
            
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
              
              <!-- Header with UC ERA Logo -->
              <div style="text-align: center; margin: 30px 0; background: linear-gradient(135deg, #2563eb, #1d4ed8); padding: 30px; border-radius: 16px; border: 4px solid #1e293b; box-shadow: 0 8px 0 #334155, 0 8px 20px rgba(0,0,0,0.15);">
                
                <!-- UC ERA Logo Pixel Art Style -->
                <div style="display: inline-block; background: #ffffff; padding: 20px; border-radius: 12px; border: 3px solid #1e293b; margin-bottom: 20px; box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);">
                  <div style="width: 80px; height: 80px; margin: 0 auto; background: linear-gradient(135deg, #3b82f6, #1e40af); border-radius: 16px; border: 3px solid #1e293b; display: flex; align-items: center; justify-content: center; position: relative; box-shadow: 0 4px 0 #334155;">
                    
                    <!-- UC ERA Letters in Pixel Style -->
                    <div style="color: #ffffff; font-weight: bold; font-size: 14px; text-shadow: 2px 2px 0 #1e293b; letter-spacing: 2px;" class="pixel-font">UC<br/>ERA</div>
                    
                    <!-- Corner Pixels -->
                    <div style="position: absolute; top: -3px; left: -3px; width: 8px; height: 8px; background: #60a5fa; border: 1px solid #1e293b;"></div>
                    <div style="position: absolute; top: -3px; right: -3px; width: 8px; height: 8px; background: #60a5fa; border: 1px solid #1e293b;"></div>
                    <div style="position: absolute; bottom: -3px; left: -3px; width: 8px; height: 8px; background: #60a5fa; border: 1px solid #1e293b;"></div>
                    <div style="position: absolute; bottom: -3px; right: -3px; width: 8px; height: 8px; background: #60a5fa; border: 1px solid #1e293b;"></div>
                  </div>
                </div>
                
                <h1 class="pixel-font float" style="color: #ffffff; margin: 0; font-size: 20px; text-shadow: 3px 3px 0 #1e293b;">
                  UC ERA
                </h1>
                <p style="color: #e2e8f0; margin: 10px 0 0 0; font-size: 14px;">
                  🔐 Email Verification
                </p>
              </div>

              <!-- Main Content -->
              <div class="pixel-block" style="margin: 20px 0; padding: 30px; border-radius: 16px; background: #ffffff;">
                
                <!-- Verification Icon -->
                <div style="text-align: center; margin-bottom: 25px;">
                  <div style="display: inline-block; width: 60px; height: 60px; background: linear-gradient(135deg, #10b981, #059669); border-radius: 50%; border: 4px solid #1e293b; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 0 #334155;" class="float">
                    <span style="color: #ffffff; font-size: 28px;">🔑</span>
                  </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 25px;">
                  <h2 class="pixel-font" style="color: #1e293b; margin: 0; font-size: 16px;">
                    Verification Code
                  </h2>
                  <p style="color: #64748b; margin: 10px 0 0 0; font-size: 14px;">
                    ${userName ? `Hello ${userName}!` : 'Hello!'} Please use the code below to verify your email.
                  </p>
                </div>
                
                <!-- OTP Code Display -->
                <div style="text-align: center; margin: 30px 0;">
                  <div class="glow" style="display: inline-block; padding: 20px 30px; border-radius: 12px; background: linear-gradient(135deg, #3b82f6, #1d4ed8);">
                    <div style="background: #ffffff; padding: 15px 25px; border-radius: 8px; border: 2px solid #1e293b;">
                      <span class="mono-font" style="color: #1e293b; font-size: 32px; font-weight: bold; letter-spacing: 4px;">
                        ${otpCode}
                      </span>
                    </div>
                  </div>
                </div>
                
                <!-- Instructions -->
                <div style="background: #f8fafc; padding: 20px; border-radius: 12px; border: 3px solid #e2e8f0; margin: 25px 0;">
                  <div style="text-align: center; margin-bottom: 15px;">
                    <span style="font-size: 24px;">⏰</span>
                  </div>
                  <p style="color: #475569; margin: 0; text-align: center; font-size: 14px; line-height: 1.6;">
                    <strong>This verification code expires in 10 minutes.</strong><br>
                    Enter this code in the UC ERA app to complete your email verification.
                  </p>
                </div>
                
                <!-- Security Note -->
                <div style="background: #fef3c7; padding: 20px; border-radius: 12px; border: 3px solid #f59e0b; margin: 20px 0;">
                  <div style="text-align: center; margin-bottom: 10px;">
                    <span style="font-size: 20px;">🛡️</span>
                  </div>
                  <p style="color: #92400e; margin: 0; text-align: center; font-size: 13px; line-height: 1.6;">
                    <strong>Security Reminder:</strong><br>
                    • Never share this code with anyone<br>
                    • UC ERA will never ask for this code via phone or email<br>
                    • If you didn't request this code, please ignore this email
                  </p>
                </div>
              </div>

              <!-- Footer -->
              <div style="text-align: center; margin: 20px 0; padding: 25px; background: #f8fafc; border-radius: 16px; border: 3px solid #e2e8f0;">
                
                <p style="color: #64748b; font-size: 12px; margin: 0 0 15px 0;">
                  📧 Email sent to: <strong>${email}</strong>
                </p>
                
                <div style="background: #e2e8f0; padding: 15px; border-radius: 8px; margin: 15px 0;">
                  <p class="pixel-font" style="color: #475569; font-size: 8px; margin: 0; line-height: 1.8;">
                    © 2025 UC ERA<br>
                    <span style="font-size: 7px;">Myanmar Tech Community Platform</span>
                  </p>
                </div>
                
                <p style="color: #94a3b8; font-size: 11px; margin: 10px 0 0 0;">
                  UC ERA Team | Myanmar<br>
                  <span style="font-size: 10px;">Building the Future of Tech in Myanmar 🇲🇲</span>
                </p>
              </div>
              
            </div>
            
          </body>
          </html>
        `
      })
    });

    log(`📬 Resend API Response Status: ${resendResponse.status}`);

    if (!resendResponse.ok) {
      const errorText = await resendResponse.text();
      error(`Resend API error: ${resendResponse.status} - ${errorText}`);
      return res.json({ 
        success: false, 
        error: 'Failed to send email',
        details: errorText
      }, 500);
    }

    const resendData = await resendResponse.json();
    log(`✅ Email sent successfully. Message ID: ${resendData.id}`);

    return res.json({
      success: true,
      message: 'OTP email sent successfully',
      messageId: resendData.id
    });

  } catch (err) {
    error(`❌ Function error: ${err.message}`);
    error(`Error stack: ${err.stack}`);

    return res.json({
      success: false,
      error: 'Internal server error',
      details: err.message
    }, 500);
  }
};